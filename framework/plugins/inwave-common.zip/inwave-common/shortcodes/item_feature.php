<?php

/*
 * Inwave_Item_Feature for Visual Composer
 */
if (!class_exists('Inwave_Item_Feature')) {

    class Inwave_Item_Feature extends Inwave_Shortcode{

        protected $name = 'inwave_item_feature';

        function init_params() {
            return array(
                'name' => __("Item feature", 'inwave-common'),
                'description' => __('Add a item info', 'inwave-common'),
                'base' => $this->name,
                'category' => 'Theme Custom',
                'icon' => 'iw-default',
                'params' => array(
                    array(
                        'type' => 'textfield',
                        "admin_label" => true,
                        "heading" => __("Title", "inwave-common"),
                        "value" => "",
                        "param_name" => "title",
                    ),
                    array(
                        'type' => 'iw_icon',
                        "heading" => __("Icon", "inwave-common"),
                        "value" => "",
                        "param_name" => "icon",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Icon Size", "inwave-common"),
                        "param_name" => "icon_size",
                        "description" => __("Example: 70px", "inwave-common"),
                        "value" => "70px",
                    ),
                    array(
                        'type' => 'textarea',
                        "heading" => __("Description", "inwave-common"),
                        "value" => "",
                        "param_name" => "description",
                    ),
                    array(
                        'type' => 'textfield',
                        "admin_label" => true,
                        "heading" => __("Height Item", "inwave-common"),
                        "value" => "200px",
                        "param_name" => "height_item",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwave-common"),
                        "param_name" => "class",
                        "description" => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', "inwave-common")
                    ),
                    array(
                        'type' => 'css_editor',
                        'heading' => __( 'CSS box', 'js_composer' ),
                        'param_name' => 'css',
                        'group' => __( 'Design Options', 'js_composer' )
                    )
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {
            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = $class = '';
            extract(shortcode_atts(array(
                'title' => '',
                'icon' => '',
                'icon_size' => '',
                'description' => '',
                'height_item' => '',
                'css' => '',
                'class' => '',
            ), $atts));

            $class .= ' '. vc_shortcode_custom_css_class( $css);


            $output .= '<div class="iw-item-feature ' . $class . '" style="height: '.$height_item.'">';
            $output .= '<div class="content-item">';
            if ($icon){
                $output .= '<div class="icon theme-color" style="font-size:' . $icon_size . '"><i class="'.esc_attr($icon).'"></i></div>';
            }
            if ($title){
                $output .= '<h3 class="title">'.$title.'</h3>';
            }
            if ($description){
                $output .= '<p class="description">'.$description.'</p>';
            }
            $output .= '</div>';
            $output .= '</div>';

            return $output;
        }
    }
}

new Inwave_Item_Feature;
